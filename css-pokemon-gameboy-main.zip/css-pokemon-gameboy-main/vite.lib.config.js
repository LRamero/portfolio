import config from './vite.lib.common.js'

export default config
