import config from './vite.lib.common.js'

config.build.cssMinify = false

export default config
